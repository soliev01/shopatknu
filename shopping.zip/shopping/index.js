const express = require('express')
const app = new express()
const cors = require('cors');
var nodemailer = require("nodemailer");
const ejs = require('ejs')
app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

let port = process.env.PORT;
if (port == null||port==""){
    port = 4000;
}
app.listen(port, () => { console.log('App listening on port 4000')})

app.get('/', (req, res)=>{
    res.render('index');
})
app.get('/about', (req, res)=>{
    res.render('about');
})
app.get('/contact', (req, res)=>{
    res.render('contact');
})
app.get('/login', (req, res)=>{
    res.render('login');
})
app.get('/shopping-cart', (req, res)=>{
    res.render('shopping-cart');
})

app.get('/team', (req, res)=>{
    res.render('team');
})


// departments link
app.get('/it', (req, res)=>{
    res.render('it');
})
app.get('/engineering', (req, res)=>{
    res.render('engineering');
})
app.get('/languages', (req, res)=>{
    res.render('languages');
})
app.get('/law', (req, res)=>{
    res.render('law');
})
app.get('/business', (req, res)=>{
    res.render('business');
})
app.get('/sports', (req, res)=>{
    res.render('sports');
})
app.get('/news', (req, res)=>{
    res.render('knu-news');
})



// mail sending part

app.post('/index.js',  cors(), (req, res) =>{

    var name = req.body["contact-name"];
    var mail = req.body["contact-email"];
    var subject = req.body["contact-subject"]
    var message = req.body["contact-message"];
   
    res.render('index');
  
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'luckyou01q@gmail.com',
          pass: 'dezneh-Remjyx-diqxa1'
        }
      });
      
      var mailOptions = {
        from: name,
        to: 'abduvositsoliev@gmail.com',
        subject: subject,
        text: 
        "name: "+name +" email: " + mail+" user message: "+message
      };
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });  
  });
